// data/eventData.js
export const upcomingEvents = [
  {
    id: 1,
    title: 'AI & Future Tech Symposium',
    date: 'May 15, 2025',
    location: 'Online / Main Hall',
    description: 'Explore cutting-edge AI trends with industry experts and hands-on workshops.',
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600',
    attendees: 0,
  },
  {
    id: 2,
    title: 'PCB Design Hackathon',
    date: 'June 5-6, 2025',
    location: 'Electronics Lab',
    description: '24-hour challenge to design innovative PCBs for real-world problems.',
    image: 'https://images.unsplash.com/photo-1581092335873-4c5c4d0b1b5d?w=600',
    attendees: 0,
  },
  {
    id: 3,
    title: 'IEEE ComSoc Workshop',
    date: 'June 20, 2025',
    location: 'Conference Room A',
    description: 'Deep dive into 5G, IoT and communication technologies.',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600',
    attendees: 0,
  },
];

export const pastEvents = [
  {
    id: 4,
    title: 'Robotics Bootcamp',
    date: 'March 12, 2025',
    location: 'Innovation Hub',
    description: 'Hands-on robotics and Arduino programming for beginners.',
    image: 'https://images.unsplash.com/photo-1581091226033-d5c48150dbaa?w=600',
    attendees: 85,
  },
  {
    id: 5,
    title: 'Cybersecurity Awareness',
    date: 'Feb 20, 2025',
    location: 'Auditorium',
    description: 'Ethical hacking and network security essentials.',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600',
    attendees: 120,
  },
];