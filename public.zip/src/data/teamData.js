// data/teamData.js
export const teamMembers = [
  { id: 1, name: 'Dr. Sarah Chen', position: 'Chairperson', avatar: 'https://randomuser.me/api/portraits/women/68.jpg' },
  { id: 2, name: 'Michael Rodriguez', position: 'Vice Chair', avatar: 'https://randomuser.me/api/portraits/men/32.jpg' },
  { id: 3, name: 'Priya Patel', position: 'Secretary', avatar: 'https://randomuser.me/api/portraits/women/44.jpg' },
  { id: 4, name: 'James Kim', position: 'Treasurer', avatar: 'https://randomuser.me/api/portraits/men/22.jpg' },
  { id: 5, name: 'Alex Johnson', position: 'Webmaster', avatar: 'https://randomuser.me/api/portraits/men/85.jpg' },
  { id: 6, name: 'Dr. Emily Zhao', position: 'Technical Head', avatar: 'https://randomuser.me/api/portraits/women/90.jpg' },
];