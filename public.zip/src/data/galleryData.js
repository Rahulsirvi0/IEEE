// data/galleryData.js
export const galleryImages = [
  { src: 'https://images.unsplash.com/photo-1517245386807-bb43f82c0c7c?w=600', alt: 'Annual Tech Fest 2024' },
  { src: 'https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?w=600', alt: 'IEEE Coding Challenge' },
  { src: 'https://images.unsplash.com/photo-1581092162384-8cb2dfb6d2da?w=600', alt: 'Workshop on IoT' },
  { src: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600', alt: 'Team Meetup' },
  { src: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?w=600', alt: 'Industry Panel' },
  { src: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=600', alt: 'Hackathon Winners' },
];